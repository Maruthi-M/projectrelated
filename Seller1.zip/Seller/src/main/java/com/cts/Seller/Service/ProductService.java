package com.cts.Seller.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Seller.Model.Product;
import com.cts.Seller.Model.Seller;
import com.cts.Seller.Repository.ProductRepository;
import com.cts.Seller.Repository.SellerRepository;
@Service
public class ProductService {
	@Autowired 
	ProductRepository productdao;
	@Autowired 
	SellerRepository sellerdao;
	
	public List<Product> getProduct(int pid, int sid) {
		
		return productdao.getProduct(pid,sid);
	}
	//adding product
	public String addProduct(Product product, int sid) {
	Seller s=sellerdao.getOne(sid);
	product.setSeller(s);
	 productdao.save(product);
	return "\"product added\"";
		
	}
	//delete product
	public String deleteproduct(int sid) {
		productdao.deleteById(sid);
		return "\"product deleted\"";
	}

}
