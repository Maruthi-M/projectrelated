import { Component, OnInit } from '@angular/core';
import { Modelproduct } from '../modelproduct';
import { Service1Service } from '../service1.service';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
product:Modelproduct;
  constructor(private productservice:Service1Service) { }

  ngOnInit(): void {
  }
onSubmit()
{
console.log("product added");

}
}
/**onSubmit()
  {
console.log("buyer adding method");
this.buyerservice.addBuyer(this.b).subscribe(b=>{
  this.router.navigate(['search']);
  });
  } */