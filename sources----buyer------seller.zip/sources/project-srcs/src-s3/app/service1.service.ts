import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from 'rxjs';
import{seller} from './seller';

@Injectable({
  providedIn: 'root'
})
export class Service1Service {
  private baseUrl='http://localhost:8081/';
  private baseUrl1='http://localhost:8080';

  constructor(private http:HttpClient) { }
 getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addSeller(s:seller)
  {
    return this.http.post(`${this.baseUrl}/addSeller/`,s);
  }
  addProduct(sellerid:seller)
  {
    return this.http.post(`${this.baseUrl}/addProduct`,sellerid)
  }
viewproducts():Observable<any>
{
  return this.http.get('http://localhost:8081/viewproducts/2');
}

}
/**
 * --
 *viewproducts/{sellerId} ----createUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl, user);
  } */
/**deleteUser(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(this.baseUrl + id);
  } */
/**import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCart } from './ShoppingCart';


@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {
  private baseUrl = 'http://localhost:8080/';
  //private baseurl1='http://localhost:8080/addCartItem/100';


  constructor(private http: HttpClient) {}
  getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addCartItem(cart:ShoppingCart):Observable<any>
  {
  
    return this.http.post(`http://localhost:8081/addCartItem/101`,cart);
  }
  getCartItemsById():Observable<any>
  {
    return this.http.get('http://localhost:8081/getCartItemsById/100')
  }
}
 */