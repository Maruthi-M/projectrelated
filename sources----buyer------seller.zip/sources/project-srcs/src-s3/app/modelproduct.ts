export class Modelproduct
{
    productId: number;
    productName: string;
    manufacture: String;
    model: String;
    price:number;
    numberOfProducts:number;
    description:String;
}
/**private int productId;
	private String productName;
	private String manufacture;
	private String model;
	private float price;
	private int numberOfProducts; */