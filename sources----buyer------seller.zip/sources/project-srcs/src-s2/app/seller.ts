export class seller
{
    userName:String;
    password:String;
    companyName:String;
    gstin:String;
    companyDescription:String;
    postalAddress:String;
    website:String;
    emailId:String;
    contactNo:String;

}
