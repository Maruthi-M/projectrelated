import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from 'rxjs';
import{Shoppingcart} from './shoppingcart';
import{buyer} from './buyer';
import{seller} from './seller';

@Injectable({
  providedIn: 'root'
})
export class Service1Service {
  private baseUrl='http://localhost:8081/';
  private baseUrl1='http://localhost:8080';

  constructor(private http:HttpClient) { }
  getCartItemsById():Observable<any>
  {
    return this.http.get('http://localhost:8080/getCartItemsById/1');
  }
  getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addCartItem(cart:Shoppingcart):Observable<any>
  {
  return this.http.post(`http://localhost:8080/addCartItem/1`,cart);
  }
  deleteCartItem(cartId:number)
  {
    return this.http.delete(`${this.baseUrl1}/deleteCartItem/${cartId}`);
  }
  addBuyer(b:buyer)
  {
return this.http.post(`${this.baseUrl1}/addBuyer/`,b);
  }
  addSeller(s:seller)
  {
    return this.http.post(`${this.baseUrl}/addSeller/`,s);
  }

}
/**createUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl, user);
  } */
/**deleteUser(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(this.baseUrl + id);
  } */
/**import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCart } from './ShoppingCart';


@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {
  private baseUrl = 'http://localhost:8080/';
  //private baseurl1='http://localhost:8080/addCartItem/100';


  constructor(private http: HttpClient) {}
  getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addCartItem(cart:ShoppingCart):Observable<any>
  {
  
    return this.http.post(`http://localhost:8081/addCartItem/101`,cart);
  }
  getCartItemsById():Observable<any>
  {
    return this.http.get('http://localhost:8081/getCartItemsById/100')
  }
}
 */