export class Modelproduct
{
    productId: number;
    productName: string;
    manufacture: String;
    model: String;
    price:number;
    numberOfProducts:number;
    description:String;
}