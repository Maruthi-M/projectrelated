package com.cts.SpringBoot;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class Items implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int itemId;
	private String itemName;
	private String Description;
	private float price;
	private int stockNumber;
	private String remarks;
	@ManyToOne
	@JoinColumn(name="category_key")
	private Category category;
	@ManyToOne
	@JoinColumn(name="subcategory_key")
	private SubCategory subcategory;
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public SubCategory getSubcategory() {
		return subcategory;
	}
	public void setSubcategory(SubCategory subcategory) {
		this.subcategory = subcategory;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getStockNumber() {
		return stockNumber;
	}
	public void setStockNumber(int stockNumber) {
		this.stockNumber = stockNumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Items(int itemId, SubCategory subcategory, String itemName, String description, float price, int stockNumber,
			String remarks) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		Description = description;
		this.price = price;
		this.stockNumber = stockNumber;
		this.remarks = remarks;
	}
	public Items() {
		super();
	}
	
}
