package com.cts.SpringBoot;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class ShoppingCart implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cartId;
	private int cartQuantity;
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getCartQuantity() {
		return cartQuantity;
	}
	public void setCartQuantity(int cartQuantity) {
		this.cartQuantity = cartQuantity;
	}
	public ShoppingCart(int cartId, int cartQuantity) {
		super();
		this.cartId = cartId;
		this.cartQuantity = cartQuantity;
	}
	public ShoppingCart() {
		super();
	}

}
