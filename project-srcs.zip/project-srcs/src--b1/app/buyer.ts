export class buyer
{
    buyerId:number;
    username:String;
    password:String;
    email:String;
    mobileNumber:number;
    address:number;
    
}