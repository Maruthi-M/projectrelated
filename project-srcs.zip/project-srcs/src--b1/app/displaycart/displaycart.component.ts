import { Component, OnInit } from '@angular/core';

import {Service1Service} from '../service1.service';
import { Shoppingcart } from '../Shoppingcart';
import { Router } from '@angular/router';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
cartitems:Shoppingcart;
c:any;
  constructor(private productservice:Service1Service,private router:Router) { }

  ngOnInit(): void {
    console.log("display cart component");
    this.productservice.getCartItemsById().subscribe(cartitems=>this.cartitems=cartitems);
  }
  /*deleteCartItem()
  {
    console.log("delete cart item method");
    this.productservice.deleteCartItem().subscribe(cartitems=>this.cartitems=cartitems);
  }
  deleteUser(user: User): void {
    this.apiService.deleteUser(user.id)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };
  ------------------------------------------------------------
  onSubmit() {
    this.apiService.createUser(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-user']);
      });
  } 
*/
  deleteCartItem(v):void
  {
    console.log("delete cart item method");
    this.productservice.deleteCartItem(v).subscribe(c=>{this.router.navigate(['cartitems'])});
  }

}
