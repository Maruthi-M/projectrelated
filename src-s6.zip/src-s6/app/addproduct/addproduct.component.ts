import { Component, OnInit } from '@angular/core';
import { modelproduct } from '../modelproduct';
import { Service1Service } from '../service1.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {
product:modelproduct=new modelproduct();
  constructor(private productservice:Service1Service,private router:Router) { }

  ngOnInit(): void {
    
  }
onSubmit()
{
console.log("product added");
this.productservice.addProduct(this.product).subscribe(product=>{this.router.navigate(['productlist'])});
//this.sellerservice.addSeller(this.s).subscribe(s=>{this.router.navigate(['header'])});
}
}
/**onSubmit()
  {
console.log("buyer adding method");
this.buyerservice.addBuyer(this.b).subscribe(b=>{
  this.router.navigate(['search']);
  });
  } */