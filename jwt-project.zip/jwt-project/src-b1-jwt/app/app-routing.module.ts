import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { SearchComponent } from './search/search.component';
import { ProductsComponent } from './products/products.component';
import { HeaderComponent } from './header/header.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { PurchasehistoryComponent } from './purchasehistory/purchasehistory.component';
import { CheckoutComponent } from './checkout/checkout.component';


const routes: Routes = [
  {path:'',component:WelcomeComponent},
  {path:'cartitems',component:DisplaycartComponent},
  {path:'loginbuyer',component:LoginComponent},
  {path:'signup',component:SignupComponent},
{path:'search',component:SearchComponent},
{path:'purchasehistory',component:PurchasehistoryComponent},
{path:'checkout',component:CheckoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
