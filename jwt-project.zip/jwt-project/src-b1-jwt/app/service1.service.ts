import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from 'rxjs';
import{Shoppingcart} from './shoppingcart';
import{buyer, ApiResponse} from './buyer';
import { transactions } from './transactions';
import { purchasehistory } from './purchasehistory';

@Injectable({
  providedIn: 'root'
})
export class Service1Service {
  private baseUrl='http://localhost:8788';
  private baseUrl1='http://localhost:8787';

  constructor(private http:HttpClient) { }
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8787/' + 'token/generate-token', loginPayload);
  }
  getCartItemsById():Observable<any>
  {
    return this.http.get('http://localhost:8787/getCartItemsById/1');
  }
  getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addCartItem(cart:Shoppingcart):Observable<any>
  {
  return this.http.post(`http://localhost:8787/addCartItem/1`,cart);
  }
  deleteCartItem(cartId:number) : Observable<any>
  {
    return this.http.delete(`${this.baseUrl1}/deleteCartItem/${cartId}`);
  }
  addBuyer(b:buyer)
  {
return this.http.post(`http://localhost:8787/addBuyer`,b);
  }
updatecart(cartId:number,cart:Shoppingcart)
{
  return this.http.put(`${this.baseUrl1}/updatecart/${cartId}`,cart);
}
checkout(trs:transactions):Observable<any>
{
  return this.http.post(`${this.baseUrl1}/checkout/1`,trs);
}
purchasehistory():Observable<any>
{
  return this.http.get(`${this.baseUrl1}/purchasehistory/1`);
}

}
/**updateproduct(productId:number,product:modelproduct):Observable<any>
{
  return this.http.put(`${this.baseUrl}/updateproduct/${productId}`,product);
} */
/**createUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl, user);
  } */
/**deleteUser(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(this.baseUrl + id);
  } */
/**import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCart } from './ShoppingCart';


@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {
  private baseUrl = 'http://localhost:8080/';
  //private baseurl1='http://localhost:8080/addCartItem/100';


  constructor(private http: HttpClient) {}
  getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addCartItem(cart:ShoppingCart):Observable<any>
  {
  
    return this.http.post(`http://localhost:8081/addCartItem/101`,cart);
  }
  getCartItemsById():Observable<any>
  {
    return this.http.get('http://localhost:8081/getCartItemsById/100')
  }
}
 */