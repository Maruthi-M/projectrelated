package com.egg.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.egg.model.PurchaseHistory;



@Repository
public interface PurchaseDao extends JpaRepository<PurchaseHistory,Integer>{
	@Query(value="SELECT * FROM purchase_history where buyer_key =:bid",nativeQuery = true)
	public List<PurchaseHistory> purchasehistorybybuyerid(int bid);

	
}
