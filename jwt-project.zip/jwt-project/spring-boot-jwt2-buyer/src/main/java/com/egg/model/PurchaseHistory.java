package com.egg.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;



@Entity
@Table(name="purchase_history")
public class PurchaseHistory implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int purchaseId;
	private int numberOfItems;	
	@CreationTimestamp
	private Date dateTime;
	private int productId;
	private float productprice;
	@ManyToOne
	@JoinColumn(name="buyer_key")
	private Buyer buyerId;
	
	public int getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}

	public int getNumberOfItems() {
		return numberOfItems;
	}

	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public float getProductprice() {
		return productprice;
	}

	public void setProductprice(float productprice) {
		this.productprice = productprice;
	}

	public Buyer getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(Buyer buyerId) {
		this.buyerId = buyerId;
	}

	public PurchaseHistory(int purchaseId, int numberOfItems, Date dateTime, int productId, float productprice,
			Buyer buyerId) {
		super();
		this.purchaseId = purchaseId;
		this.numberOfItems = numberOfItems;
		this.dateTime = dateTime;
		this.productId = productId;
		this.productprice = productprice;
		this.buyerId = buyerId;
	}

	public PurchaseHistory() {
		super();
	}
	
	
	
	

}

