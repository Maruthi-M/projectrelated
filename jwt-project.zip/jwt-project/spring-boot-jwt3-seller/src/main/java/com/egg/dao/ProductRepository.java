package com.egg.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.Product;


@Repository
public interface ProductRepository extends JpaRepository<Product,Integer>{

	/*@Query(value="SELECT * FROM Product where product_id =:pid and seller_id =:sid",nativeQuery = true)
	public List<Product> getProduct(int pid, int sid);*/
	@Query(value="SELECT *FROM Product where seller_Id =:sid",nativeQuery = true)
	public List<Product> viewproducts(int sid);
	@Transactional
	@Modifying
	@Query(value="DELETE FROM Product where seller_id =:sid and productId =:pid",nativeQuery= true)
	public int deleteproduct(int sid, int pid);
	//@Query(value="SELECT *FROM Product where product_name =:name",nativeQuery= true)
	@Query(value="FROM Product where productName like %:name%")
	public List<Product> getproductbyname(@Param("name")String name);
	

}
