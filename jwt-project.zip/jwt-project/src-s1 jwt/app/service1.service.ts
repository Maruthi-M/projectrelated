import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from 'rxjs';
import{seller,ApiResponse} from './seller';
import { modelproduct } from './modelproduct';

@Injectable({
  providedIn: 'root'
})
export class Service1Service {
  //private baseUrl='http://localhost:8081/';
  private baseUrl='http://localhost:8788';
  private baseUrl1='http://localhost:8080';

  constructor(private http:HttpClient) { }
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8788/' + 'token/generate-token', loginPayload);
  }
 getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addSeller(s:seller):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/addSeller`,s);
  }
  addProduct(product:modelproduct):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/addProduct/6`,product);
  }
viewproducts():Observable<any>
{
  return this.http.get('http://localhost:8788/viewproducts/6');
}
/**deleteproduct/{sellerId}/{productId} */
deleteproduct(productId:number):Observable<any>
{
return this.http.delete(`${this.baseUrl}/deleteproduct/6/${productId}`);
}
updateproduct(productId:number,product:modelproduct):Observable<any>
{
  return this.http.put(`${this.baseUrl}/updateproduct/${productId}`,product);
}
}




