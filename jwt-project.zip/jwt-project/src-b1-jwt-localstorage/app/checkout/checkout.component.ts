import { Component, OnInit } from '@angular/core';
import { Service1Service } from '../service1.service';
import { transactions } from '../transactions';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  trs:transactions=new transactions();
  constructor(private productservice:Service1Service) { }
  bid:String=localStorage.getItem("id");
  ngOnInit(): void {
  }
  performcheckout()
  {
    this.productservice.checkout(this.trs,this.bid).subscribe(msg=>{alert('products ordered successfully');});
  }
}
