import { Component, OnInit } from '@angular/core';
import { purchasehistory } from '../purchasehistory';
import { Service1Service } from '../service1.service';

@Component({
  selector: 'app-purchasehistory',
  templateUrl: './purchasehistory.component.html',
  styleUrls: ['./purchasehistory.component.css']
})
export class PurchasehistoryComponent implements OnInit {
purchase:purchasehistory=new purchasehistory();
  constructor(private purchaseservice:Service1Service) { }
  bid:String=localStorage.getItem("id");
  ngOnInit(): void {
    console.log("purchase method");
this.purchaseservice.purchasehistory(this.bid).subscribe(purchase=>this.purchase=purchase);
  }
 /* reload(){

    this.productservice.getCartItemsById().subscribe(cartitems=>this.cartitems=cartitems);

  }*/

}
