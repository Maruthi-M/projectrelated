package com.cts.Seller.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Seller.Model.Seller;
import com.cts.Seller.Service.SellerService;


@RestController
public class SellerController {
	@Autowired SellerService sellerservice;
	//getting all sellers
	@RequestMapping("getAllSellers")
	public List<Seller> getAllSellers()
	{
		return sellerservice.getAllSellers();
	}
	//getting seller by id
	@GetMapping("sellerbyid/{sellerid}")
	public Optional<Seller> sellerbyid(@PathVariable("sellerid") int bid)
	{
		
		return sellerservice.sellerById(bid);

}
//getting by seller Id	
	@RequestMapping("getById/{eid}")
	public Seller getbyId(@PathVariable("eid") int sid) {
		
		Optional<Seller> p=sellerservice.getSellerById(sid);
		Seller pObj=null;
		if(p.isPresent()){
		 pObj=p.get();	
		}		
		return pObj;
	}
	//adding seller
	@PostMapping("addSeller")
	public Seller addSeller(@RequestBody Seller seller)
	{
		return sellerservice.addSeller(seller);
	}
}