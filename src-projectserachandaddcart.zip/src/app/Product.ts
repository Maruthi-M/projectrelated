export class Product {
    productId: number;
    productName: string;
    manufacture: String;
    model: String;
    price:number;
    numberOfProduct:number;
    description:String;
}