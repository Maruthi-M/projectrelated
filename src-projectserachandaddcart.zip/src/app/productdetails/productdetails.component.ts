import { Component, OnInit,Input } from '@angular/core';
import {Product} from '../Product';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  //template:`{{product|json}}`,
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {

  constructor() { }

@Input() product: Product[]



  ngOnInit(): void {
  }

}
