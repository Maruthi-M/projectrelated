import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {
  private baseUrl = 'http://localhost:8080/';


  constructor(private http: HttpClient) {}
  getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  /*addCartItem(productId:Number,buyerId:Number):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/addCartItem/${buyerId}`);
  }*/
}
