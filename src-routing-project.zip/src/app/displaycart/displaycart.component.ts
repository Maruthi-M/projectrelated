import { Component, OnInit } from '@angular/core';
import { Shoppingcart } from '../Product';
import {Service1Service} from '../service1.service';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
cartitems:Shoppingcart;
  constructor(private productservice:Service1Service) { }

  ngOnInit(): void {
    console.log("display cart component");
    this.productservice.getCartItemsById().subscribe(cartitems=>this.cartitems=cartitems);
  }

}
