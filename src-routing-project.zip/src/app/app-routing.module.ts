import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {path:'cartitems',component:DisplaycartComponent},
  {path:'loginbuyer',component:LoginComponent},
  {path:'signup',component:SignupComponent},
{path:'search',component:SearchComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
