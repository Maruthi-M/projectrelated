export class Shoppingcart
{
    numberOfItems:number;
    productId:number;
    price:number;
} 