export class Shoppingcart
{
    productName:String;
    manufacture:String;
    model:String;
    price:number;
    numberOfProducts:number;
    description:String;
}