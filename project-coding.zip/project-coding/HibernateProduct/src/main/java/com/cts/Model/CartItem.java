package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class CartItem implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cartItem;
	private String description;
	public int getCartItem() {
		return cartItem;
	}
	public void setCartItem(int cartItem) {
		this.cartItem = cartItem;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public CartItem(int cartItem, String description) {
		
		this.cartItem = cartItem;
		this.description = description;
	}
	public CartItem() {
	
	}

}
