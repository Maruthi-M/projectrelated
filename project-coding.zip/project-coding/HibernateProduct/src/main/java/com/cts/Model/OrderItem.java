package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class OrderItem implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int orderitemid;
	private String deatils;
	@ManyToOne
	@JoinColumn(name="oI")
	private Order1 order;
	public int getOrderitemid() {
		return orderitemid;
	}
	public void setOrderitemid(int orderitemid) {
		this.orderitemid = orderitemid;
	}
	public String getDeatils() {
		return deatils;
	}
	public void setDeatils(String deatils) {
		this.deatils = deatils;
	}
	public Order1 getOrder() {
		return order;
	}
	public void setOrder(Order1 order) {
		this.order = order;
	}
	public OrderItem(int orderitemid, String deatils, Order1 order) {
		
		this.orderitemid = orderitemid;
		this.deatils = deatils;
		this.order = order;
	}
	public OrderItem() {
		
	}
	

}
