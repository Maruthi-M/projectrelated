package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Cart implements Serializable {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private int cartId;
private int quantity;
@OneToOne
private CartItem cartitem;
public int getCartId() {
	return cartId;
}
public void setCartId(int cartId) {
	this.cartId = cartId;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public CartItem getCartitem() {
	return cartitem;
}
public void setCartitem(CartItem cartitem) {
	this.cartitem = cartitem;
}
public Cart(int cartId, int quantity, CartItem cartitem) {
	this.cartId = cartId;
	this.quantity = quantity;
	this.cartitem = cartitem;
}
public Cart() {
	
}


}
