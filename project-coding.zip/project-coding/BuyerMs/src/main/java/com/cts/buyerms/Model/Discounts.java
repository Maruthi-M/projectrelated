package com.cts.buyerms.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Discounts implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int discountId;
	private String discountCode;
	private float percentage;
	private String StartDate;
	private String EndDate;
	private String Description;
	public int getDiscountId() {
		return discountId;
	}
	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public String getStartDate() {
		return StartDate;
	}
	public void setStartDate(String startDate) {
		StartDate = startDate;
	}
	public String getEndDate() {
		return EndDate;
	}
	public void setEndDate(String endDate) {
		EndDate = endDate;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Discounts(int discountId, String discountCode, float percentage, String startDate, String endDate,
			String description) {
		super();
		this.discountId = discountId;
		this.discountCode = discountCode;
		this.percentage = percentage;
		StartDate = startDate;
		EndDate = endDate;
		Description = description;
	}
	public Discounts() {
		super();
	}
	
	
	
	

}
