package com.cts.buyerms.Model;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class PurchaseHistory implements Serializable{
	private int puchaseId;
	private int numberOfItems;
	private String DateTime;
	private String remarks;
	private int buyerId;
	private int sellerId;
	private int itemId;
	private int transactionId;
	public PurchaseHistory(int puchaseId, int numberOfItems, String dateTime, String remarks, int buyerId, int sellerId,
			int itemId, int transactionId) {
		super();
		this.puchaseId = puchaseId;
		this.numberOfItems = numberOfItems;
		DateTime = dateTime;
		this.remarks = remarks;
		this.buyerId = buyerId;
		this.sellerId = sellerId;
		this.itemId = itemId;
		this.transactionId = transactionId;
	}
	public int getPuchaseId() {
		return puchaseId;
	}
	public void setPuchaseId(int puchaseId) {
		this.puchaseId = puchaseId;
	}
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public String getDateTime() {
		return DateTime;
	}
	public void setDateTime(String dateTime) {
		DateTime = dateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
	public int getSellerId() {
		return sellerId;
	}
	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public PurchaseHistory() {
		super();
	}
	

}
