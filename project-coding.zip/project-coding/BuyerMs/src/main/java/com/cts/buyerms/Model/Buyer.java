package com.cts.buyerms.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Buyer implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Id;
	private String username;
	private String Password;
	private String Email;
	private float mobileNumber;
	private float createdDateTime;
	@OneToOne
	@JoinColumn(name="Buyercart_key")
	private ShoppingCart cart;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public float getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(float mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public float getCreatedDateTime() {
		return createdDateTime;
	}
	public void setCreatedDateTime(float createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	public ShoppingCart getCart() {
		return cart;
	}
	public void setCart(ShoppingCart cart) {
		this.cart = cart;
	}
	public Buyer(int id, String username, String password, String email, float mobileNumber, float createdDateTime,
			ShoppingCart cart) {
		super();
		Id = id;
		this.username = username;
		Password = password;
		Email = email;
		this.mobileNumber = mobileNumber;
		this.createdDateTime = createdDateTime;
		this.cart = cart;
	}
	public Buyer() {
		super();
	}
	
	

}
