package com.cts.buyerms.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class SubCategory implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int subcategoryId;
	private String subcategoryName;
	private String subcategoryDeatils;
	private float gst;
	@ManyToOne
	private Category catogory;
	public int getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public String getSubcategoryName() {
		return subcategoryName;
	}
	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}
	public String getSubcategoryDeatils() {
		return subcategoryDeatils;
	}
	public void setSubcategoryDeatils(String subcategoryDeatils) {
		this.subcategoryDeatils = subcategoryDeatils;
	}
	public float getGst() {
		return gst;
	}
	public void setGst(float gst) {
		this.gst = gst;
	}
	public SubCategory(int subcategoryId, String subcategoryName, String subcategoryDeatils, float gst) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryName = subcategoryName;
		this.subcategoryDeatils = subcategoryDeatils;
		this.gst = gst;
	}
	public SubCategory() {
		super();
	}
	
	

}
