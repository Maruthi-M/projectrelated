package com.cts.buyerms.Model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Category implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
private int categoryId;
private String categoryName;
private String categoryBriefDetails;
@OneToMany
@JoinColumn(name="cate_suncakey")
private List<SubCategory> subcategory;

public int getCategoryId() {
	return categoryId;
}

public void setCategoryId(int categoryId) {
	this.categoryId = categoryId;
}

public String getCategoryName() {
	return categoryName;
}

public void setCategoryName(String categoryName) {
	this.categoryName = categoryName;
}

public String getCategoryBriefDetails() {
	return categoryBriefDetails;
}

public void setCategoryBriefDetails(String categoryBriefDetails) {
	this.categoryBriefDetails = categoryBriefDetails;
}

public List<SubCategory> getSubcategory() {
	return subcategory;
}

public void setSubcategory(List<SubCategory> subcategory) {
	this.subcategory = subcategory;
}


public Category(int categoryId, String categoryName, String categoryBriefDetails, List<SubCategory> subcategory) {
	super();
	this.categoryId = categoryId;
	this.categoryName = categoryName;
	this.categoryBriefDetails = categoryBriefDetails;
	this.subcategory = subcategory;
}

public Category() {
	super();
}


}
