import { Component, OnInit } from '@angular/core';
import {SellerserviceService} from '../sellerservice.service';
import { ShoppingCart } from 'src-1/app/ShoppingCart';
@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
cartitems:ShoppingCart;
  constructor(private productService:SellerserviceService) { }

  ngOnInit(): void {
    console.log("display cart component");
    this.productService.getCartItemsById().subscribe(cartitems=>this.cartitems=cartitems);
    //this.sService.getProductByName(this.productname).subscribe(product=>this.product=product);
  }

}
