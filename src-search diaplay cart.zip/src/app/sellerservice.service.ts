import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ShoppingCart } from './ShoppingCart';


@Injectable({
  providedIn: 'root'
})
export class SellerserviceService {
  private baseUrl = 'http://localhost:8080/';
  //private baseurl1='http://localhost:8080/addCartItem/100';


  constructor(private http: HttpClient) {}
  getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addCartItem(cart:ShoppingCart):Observable<any>
  {
  
    return this.http.post(`http://localhost:8081/addCartItem/101`,cart);
  }
  getCartItemsById():Observable<any>
  {
    return this.http.get('http://localhost:8081/getCartItemsById/100')
  }
}
