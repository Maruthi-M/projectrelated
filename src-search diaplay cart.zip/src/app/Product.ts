export class Product {
    productId: number;
    productName: string;
    manufacture: String;
    model: String;
    price:number;
    numberOfProducts:number;
    description:String;
}
