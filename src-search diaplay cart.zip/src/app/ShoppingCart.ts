export class ShoppingCart
{
    price:number;
    numberofitems:number;
    item:number;
}