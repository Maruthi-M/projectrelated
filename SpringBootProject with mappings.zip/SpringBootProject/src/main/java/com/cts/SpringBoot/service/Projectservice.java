package com.cts.SpringBoot.service;

import java.util.List;

import com.cts.SpringBoot.Buyer;

public interface Projectservice {
	//public Buyer getBuyerByName(String name);

	public List<Buyer> getAllBuyers();

}
