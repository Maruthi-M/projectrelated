package com.cts.SpringBoot.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.service.Projectservice;


@RestController
public class BuyerController {
	@Autowired 
	private Projectservice service;
	@RequestMapping("getAllBuyers")
	public List<Buyer> getAllBuyers()
	{
		return service.getAllBuyers();
	}
	/*@RequestMapping("getbyname/{name}")
	public Buyer getbyName(@PathVariable("bname") String name) {
	return service.getBuyerByName(name);
}*/
}
