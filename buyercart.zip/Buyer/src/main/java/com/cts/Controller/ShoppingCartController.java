package com.cts.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Model.ShoppingCart;
import com.cts.Service.ShoppingCartService;


@RestController
public class ShoppingCartController {
	@Autowired 
	public ShoppingCartService cartservice;
		//get cart items by id
		@RequestMapping("getCartItemsById/{bid}")
		public List<ShoppingCart> getCartItemsById(@PathVariable("bid") int bid)
		{
			
			return cartservice.getCartItemsById(bid);
			
		}
		//adding cart item
		@RequestMapping(value = "addCartItem/{buyerId}", method = RequestMethod.POST,produces = "application/json") 
		public String addCartItem(@RequestBody ShoppingCart cart,@PathVariable("buyerId") int bid)
		{
			return cartservice.addCartItem(cart,bid);
			
		}
		//delete cart item by cartId
		@DeleteMapping("deleteCartItem/{id}")
		public void deleteCartItem(@PathVariable("id") int id) {
			cartservice.deleteCartItem(id);

		}
		//deleting cart items by buyer id
		@RequestMapping("deleteCartItemByBuyerId/{bid}")
		public void deleteCartItembyid(@PathVariable("bid") int id) {
			cartservice.deleteCartItembyid(id);

		}
		//update cart item
		@RequestMapping("updatecart/{cartId}")
		public ShoppingCart updatecart(@PathVariable("cartId") int cid,@RequestBody ShoppingCart cart)
		{
			return cartservice.updatecart(cid,cart);
		
		}
		//checkout
		@RequestMapping("checkout/{buyerId}")
		public ShoppingCart checkout(@PathVariable("buyerId") int bid)
		{
			return cartservice.checkout(bid);
		}
		
		
		
		
}
