package com.cts.Seller.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Seller.Model.Product;
import com.cts.Seller.Model.Seller;
import com.cts.Seller.Repository.ProductRepository;
import com.cts.Seller.Repository.SellerRepository;
@Service
public class ProductService {
	@Autowired 
	ProductRepository productdao;
	@Autowired 
	SellerRepository servicedao;
	public Product addProduct(Product product) {
		return productdao.save(product);
	}
	public List<Product> getProduct(int pid, int sid) {
		
		return productdao.getProduct(pid,sid);
	}

}
