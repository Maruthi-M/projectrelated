package com.cts.Seller.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.cts.Seller.Model.Product;
import com.cts.Seller.Service.ProductService;

@RestController
public class ProductController {
	@Autowired ProductService productservice;
	@PostMapping("addProduct")
	public Product addProduct(@RequestBody Product product)
	{
		return productservice.addProduct(product);
	}
	@GetMapping("getProduct/{productId}/{sellerId}")
	public List<Product> getProduct(@PathVariable(value="productid") int pid,@PathVariable(value="sellerid") int sid)
	{
		return productservice.getProduct(pid,sid);
	}

}
