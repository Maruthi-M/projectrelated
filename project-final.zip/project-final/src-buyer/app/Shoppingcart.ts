export class Shoppingcart
{
    cartId:number;
    numberOfItems:number;
    productId:number;
    price:number;
    productName:String;
} 