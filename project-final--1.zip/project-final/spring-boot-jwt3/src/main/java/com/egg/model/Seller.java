package com.egg.model;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="seller")
public class Seller implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int sellerId;
	private String userName;
	private String password;
	private String companyName;
	private String gstin;
	private String companyDescription;
	private String postalAddress;
	private String website;
	private String emailId;
	private String contactNo;
	
	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getGstin() {
		return gstin;
	}

	public void setGstin(String gstin) {
		this.gstin = gstin;
	}

	public String getCompanyDescription() {
		return companyDescription;
	}

	public void setCompanyDescription(String companyDescription) {
		this.companyDescription = companyDescription;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public Seller() {
		
	}

	public Seller(int sellerId, String userName, String password, String companyName, String gstin,
			String companyDescription, String postalAddress, String website, String emailId, String contactNo) {
		super();
		this.sellerId = sellerId;
		this.userName = userName;
		this.password = password;
		this.companyName = companyName;
		this.gstin = gstin;
		this.companyDescription = companyDescription;
		this.postalAddress = postalAddress;
		this.website = website;
		this.emailId = emailId;
		this.contactNo = contactNo;
	}
	
	

}
