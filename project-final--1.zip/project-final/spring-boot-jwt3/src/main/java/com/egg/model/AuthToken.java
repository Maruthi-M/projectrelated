package com.egg.model;

public class AuthToken {
	
    private String token;
    private String username;
    private int SellerId;
    
   
   
	public int getSellerId() {
		return SellerId;
	}


	public void setSellerId(int sellerId) {
		SellerId = sellerId;
	}


	/*public AuthToken(String token, String username) {
		super();
		this.token = token;
		this.username = username;
	}*/
	


	public String getToken() {
		return token;
	}
	public AuthToken(String token, String username, int sellerId) {
		super();
		this.token = token;
		this.username = username;
		SellerId = sellerId;
	}


	public void setToken(String token) {
		this.token = token;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public AuthToken() {
		super();
	}
	 

    

   
   

	

	
}
