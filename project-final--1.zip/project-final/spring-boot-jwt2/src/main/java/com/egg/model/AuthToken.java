package com.egg.model;

public class AuthToken {

    private String token;
    private String username;
    private int buyerId;
    

    

	public AuthToken(){

    }

   /* public AuthToken(String token, String username){
        this.token = token;
        this.username = username;
    }*/
	

    public AuthToken(String token){
        this.token = token;
    }

   

	public AuthToken(String token, String username, int buyerId) {
		super();
		this.token = token;
		this.username = username;
		this.buyerId = buyerId;
	}

	public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}
   
}
