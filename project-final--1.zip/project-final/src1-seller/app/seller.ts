export class seller
{
  sellerId:number;
    userName:String;
    password:String;
    companyName:String;
    gstin:String;
    companyDescription:String;
    postalAddress:String;
    website:String;
    emailId:String;
    contactNo:String;

}
export class ApiResponse {

    status: number;
    message: number;
    result: any;
  }
  export class User {

    id: number;
  
  }
    