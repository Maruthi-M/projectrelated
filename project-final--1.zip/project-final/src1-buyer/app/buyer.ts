export class buyer
{
    buyerId:number;
    username:String;
    password:String;
    email:String;
    mobileNumber:number;
    address:String;
    
}

export class ApiResponse {

    status: number;
    message: number;
    result: any;
  }
  export class User {

    id: number;
  
  }
    