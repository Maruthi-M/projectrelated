export class transactions
{
    /**private int transactionId;
	private String transactionType;
	@CreationTimestamp
	private Date transactionDate;
	@ManyToOne
	@JoinColumn(name="buyer_key")
    private Buyer buyerId; */
    transactionId:number;
	transactionType:String;
	transactionnumber:String;
    
}