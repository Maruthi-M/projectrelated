import { Component, OnInit } from '@angular/core';
import { Service1Service } from '../service1.service';
import { buyer } from '../buyer';
import { Router } from '@angular/router';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
b:buyer=new buyer();
//signupform:FormGroup;
  constructor(private buyerservice:Service1Service,private router:Router) { }
  
  ngOnInit(): void {
    
  }
  onSubmit()
  {
console.log("buyer adding method");
this.buyerservice.addBuyer(this.b).subscribe(b=>{
  this.router.navigate(['loginbuyer']);
  });
  }
  
}
  /**onSubmit() {
    this.apiService.createUser(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-user']);
      });
  } */


