import { Component, OnInit } from '@angular/core';
import { purchasehistory } from '../purchasehistory';
import { Service1Service } from '../service1.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-purchasehistory',
  templateUrl: './purchasehistory.component.html',
  styleUrls: ['./purchasehistory.component.css']
})
export class PurchasehistoryComponent implements OnInit {
purchase:purchasehistory=new purchasehistory();
  constructor(private purchaseservice:Service1Service,private router:Router) { }
  bid:String=localStorage.getItem("id");
  ngOnInit(): void {
    if(this.bid)
    {
    console.log("purchase method");
this.purchaseservice.purchasehistory(this.bid).subscribe(purchase=>this.purchase=purchase);
}
else
{
  this.router.navigate(['loginbuyer']);
}
  }
 /* reload(){

    this.productservice.getCartItemsById().subscribe(cartitems=>this.cartitems=cartitems);

  }*/

}
