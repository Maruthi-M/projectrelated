package com.cts.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Model.Buyer;
import com.cts.Model.ShoppingCart;
import com.cts.Repository.BuyerDao;
import com.cts.Repository.ShoppingCartDao;


@Service
public class ShoppingCartService {
	@Autowired 
	public ShoppingCartDao cartdao;
	@Autowired
	public BuyerDao buyerdao;
	//get cart item by buyer id
	public List<ShoppingCart> getCartItemsById(int bid) {
		
		return cartdao.getCartItemsById(bid);
	}
	//adding cart item
	public ShoppingCart addCartItem(ShoppingCart cart, int bid) {
		Buyer b=buyerdao.getOne(bid);
		cart.setBuyer(b);
		System.out.println(cart);
		return cartdao.save(cart);
		
	}
	//delete cart item by cartId
	public void deleteCartItem(int id) {
		cartdao.deleteById(id);
		
	}
	//deleting cart items by buyer id
	public void deleteCartItembyid(int id) {
		cartdao.deleteCartItembyid(id);
	}

}
