package com.cts.Model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="transactions")
public class PurchaseHistory implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int puchaseId;
	private int numberOfItems;
	private Date DateTime;
	private String remarks;
	private int item;
	@ManyToOne
	@JoinColumn(name="buyer_key")
	private Buyer buyer;
	@ManyToOne
	@JoinColumn(name="transaction_key")
	private Transactions transactions;
	public int getPuchaseId() {
		return puchaseId;
	}
	public void setPuchaseId(int puchaseId) {
		this.puchaseId = puchaseId;
	}
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public Date getDateTime() {
		return DateTime;
	}
	public void setDateTime(Date dateTime) {
		DateTime = dateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getItem() {
		return item;
	}
	public void setItem(int item) {
		this.item = item;
	}
	public Buyer getBuyer() {
		return buyer;
	}
	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}
	public Transactions getTransactions() {
		return transactions;
	}
	public void setTransactions(Transactions transactions) {
		this.transactions = transactions;
	}
	public PurchaseHistory(int puchaseId, int numberOfItems, Date dateTime, String remarks, int item, Buyer buyer,
			Transactions transactions) {
		super();
		this.puchaseId = puchaseId;
		this.numberOfItems = numberOfItems;
		DateTime = dateTime;
		this.remarks = remarks;
		this.item = item;
		this.buyer = buyer;
		this.transactions = transactions;
	}
	public PurchaseHistory() {
		super();
	}
	

}
