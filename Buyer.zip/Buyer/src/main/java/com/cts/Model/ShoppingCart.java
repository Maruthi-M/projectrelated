package com.cts.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="shopping_cart")
public class ShoppingCart implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cartId;
	private int numberofitems;
	private int item;
	@ManyToOne
	@JoinColumn(name="buyer_key")
	private Buyer buyer;
	
	public int getItem() {
		return item;
	}
	public void setItem(int item) {
		this.item = item;
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getNumberofitems() {
		return numberofitems;
	}
	public void setNumberofitems(int numberofitems) {
		this.numberofitems = numberofitems;
	}
	public Buyer getBuyer() {
		return buyer;
	}
	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}
	public ShoppingCart(int cartId, int numberofitems, int item,Buyer buyer) {
		super();
		this.cartId = cartId;
		this.numberofitems = numberofitems;
		this.item=item;
		this.buyer = buyer;
	}
	public ShoppingCart() {
		super();
	}
	public ShoppingCart get() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
