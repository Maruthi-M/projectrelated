package com.cts.SpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.dao.ProjectDao;

@Service
public class ProjectServiceImplementation implements Projectservice{
	@Autowired
	public ProjectDao dao;

	/*@Override
	public Buyer getBuyerByName(String name) {
		return dao.findByBuyerName(name);
	}*/

	@Override
	public List<Buyer> getAllBuyers() {
		return dao.findAll();
	}

	@Override
	public Buyer addbuyer(Buyer buyer) {
		return dao.save(buyer);
	}

	/*@Override
	public void deleteCartItem(int id) {
		 dao.deleteById(id);
	}*/

}
