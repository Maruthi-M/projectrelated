package com.cts.SpringBoot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.ShoppingCart;

@Repository
public interface ShoppingCartDao extends JpaRepository<ShoppingCart,Integer>
{

}
