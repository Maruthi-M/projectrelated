package com.cts.SpringBoot.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SpringBoot.service.ShoppingCartService;

@RestController
public class ShoppingCartController {
	@Autowired
	private ShoppingCartService service;
	//deleting an item cart
	@RequestMapping("deleteCartItem/{id}")
	public void deleteCartItem(@PathVariable("id") int id)
	{
		service.deleteCartItem(id);
	}
}
