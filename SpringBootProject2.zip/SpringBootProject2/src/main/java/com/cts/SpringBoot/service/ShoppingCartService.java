package com.cts.SpringBoot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.SpringBoot.dao.ShoppingCartDao;



@Service
public class ShoppingCartService {
@Autowired 
public ShoppingCartDao dao;
public void deleteCartItem(int id) {
	 dao.deleteById(id);
}

}
