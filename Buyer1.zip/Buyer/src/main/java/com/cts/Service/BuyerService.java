package com.cts.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.Model.Buyer;
import com.cts.Repository.BuyerDao;

@Service
public class BuyerService {
@Autowired 
public BuyerDao buyerdao;
	public List<Buyer> getAllbuyers() {
		
		return buyerdao.findAll();
	}
	public Buyer addbuyer(Buyer buyer) {
		
		return buyerdao.save(buyer);
	}

}
