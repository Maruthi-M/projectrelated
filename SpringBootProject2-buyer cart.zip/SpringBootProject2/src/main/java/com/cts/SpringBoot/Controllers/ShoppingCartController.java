package com.cts.SpringBoot.Controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.ShoppingCart;
import com.cts.SpringBoot.service.Projectservice;
import com.cts.SpringBoot.service.ShoppingCartService;

@RestController
public class ShoppingCartController 

{
	@Autowired
	private ShoppingCartService service;
	//deleting an item cart
	@RequestMapping("deleteCartItem/{id}")
	public void deleteCartItem(@PathVariable("id") int id)
	{
		service.deleteCartItem(id);
		
	}  
	//get cart items
	@RequestMapping("{bid}/getCartItems")
	public Optional<ShoppingCart> getCartItems(@PathVariable("bid") int buyerid)
	{
		return service.getCartItems(buyerid);
	}
	//add cart item
	@RequestMapping(value="/addCartItem",method=RequestMethod.POST,produces="application/json")
	public ShoppingCart addCartItem(@RequestBody ShoppingCart shoppingcart)
	{
		return service.addCartItem(shoppingcart);
	}
	
	
}
