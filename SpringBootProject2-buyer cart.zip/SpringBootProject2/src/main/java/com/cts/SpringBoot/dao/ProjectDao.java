package com.cts.SpringBoot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.SpringBoot.Buyer;

@Repository
public interface ProjectDao extends JpaRepository<Buyer,Integer>
{
/*@Query(value="FROM Buyer b where b.username=:bn")
public Buyer findByBuyerName(@Param("bn") String name);*/
	

}
