package com.cts.SpringBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.ShoppingCart;


@Repository
public interface ShoppingCartDao extends JpaRepository<ShoppingCart,Integer>
{



	/*@Query(value="FROM Person p where p.personName =:pn")
	public Person findByPersonName(@Param("pn") String name);
	@Query(value="DELETE FROM ShoppingCart sc WHERE sc.cid=:cartid AND sc.bid=buyerid")
	public void deleteCartItem(@Param("cartid") int cid,@Param("buyerid") int bid);*/

}
