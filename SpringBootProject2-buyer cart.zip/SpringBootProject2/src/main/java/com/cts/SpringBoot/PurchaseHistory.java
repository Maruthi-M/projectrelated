package com.cts.SpringBoot;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="purchase_history")
public class PurchaseHistory implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int puchaseId;
	private int numberOfItems;
	private Date DateTime;
	private String remarks;
	@ManyToOne
	@JoinColumn(name="buyer_key")
	private Buyer buyer;
	@ManyToOne
	@JoinColumn(name="item_key")
	private Items items;
	@ManyToOne
	@JoinColumn(name="transaction_key")
	private Transactions transactions;
	
	public Buyer getBuyer() {
		return buyer;
	}
	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}
	public Items getItems() {
		return items;
	}
	public void setItems(Items items) {
		this.items = items;
	}
	public Transactions getTransactions() {
		return transactions;
	}
	public void setTransactions(Transactions transactions) {
		this.transactions = transactions;
	}
	public int getPuchaseId() {
		return puchaseId;
	}
	public void setPuchaseId(int puchaseId) {
		this.puchaseId = puchaseId;
	}
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public Date getDateTime() {
		return DateTime;
	}
	public void setDateTime(Date dateTime) {
		DateTime = dateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public PurchaseHistory(int puchaseId, int numberOfItems, Date dateTime, String remarks) {
		super();
		this.puchaseId = puchaseId;
		this.numberOfItems = numberOfItems;
		DateTime = dateTime;
		this.remarks = remarks;
	}
	public PurchaseHistory() {
		super();
	}

}
