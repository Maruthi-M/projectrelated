package com.cts.SpringBoot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.ShoppingCart;
import com.cts.SpringBoot.dao.ProjectDao;
import com.cts.SpringBoot.dao.ShoppingCartDao;

@Service
public class ShoppingCartService {
@Autowired 
public ShoppingCartDao cartdao;
@Autowired 
public ProjectDao buyerdao;
public String deleteCartItem(int id) 
{
	 cartdao.deleteById(id);
	 return "cart item deleted";
}
public Optional<ShoppingCart> getCartItems(int buyerid) {
	// TODO Auto-generated method stub
	return cartdao.findById(buyerid);
}
public Optional<ShoppingCart> addCartItem(ShoppingCart cartItem, Integer buyerId) {
	return buyerdao.findById(buyerId).map(buyer -> {
        cartItem.setBuyer(buyer);
        return cartdao.save(cartItem);
    });
}
public void emptyCart(int bid) {
	cartdao.deleteAll();
	
}


/*public String addCartItem(int bid, ShoppingCart shoppingcart) {
	
	Buyer b=buyerdao.getOne(bid);
	shoppingcart.setBuyer(b);
	System.out.println(shoppingcart);
	 cartdao.save(shoppingcart);
	 return "item added";
	
}*/

}

