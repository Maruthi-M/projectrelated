package com.cts.SpringBoot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.cts.SpringBoot.ShoppingCart;
import com.cts.SpringBoot.dao.ProjectDao;
import com.cts.SpringBoot.dao.ShoppingCartDao;



@Service
public class ShoppingCartService {
@Autowired 
public ShoppingCartDao cartdao;
public String deleteCartItem(int id) 
{
	 cartdao.deleteById(id);
	 return "cart item deleted";
}
public Optional<ShoppingCart> getCartItems(int buyerid) {
	// TODO Auto-generated method stub
	return cartdao.findById(buyerid);
}
public ShoppingCart addCartItem(ShoppingCart shoppingcart) {
	
	return cartdao.save(shoppingcart);
}

}

