package com.egg.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="transactions")
public class Transactions implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int transactionId;
	private String transactionType;
	@CreationTimestamp
	private Date transactiondate;
	@ManyToOne
	@JoinColumn(name="buyer_key")
	private Buyer buyer;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public Date getTransactiondate() {
		return transactiondate;
	}
	public void setTransactiondate(Date transactiondate) {
		this.transactiondate = transactiondate;
	}
	public Buyer getBuyer() {
		return buyer;
	}
	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}
	public Transactions(int transactionId, String transactionType, Date transactiondate, Buyer buyer) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactiondate = transactiondate;
		this.buyer = buyer;
	}
	public Transactions() {
		super();
	}
	
	
	

}
