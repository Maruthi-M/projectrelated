package com.egg.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="buyer")
public class Buyer implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int Id;
	private String username;
	private String Password;
	private String Email;
	private long mobileNumber;
	@CreationTimestamp
	private Date createdDateTime;
	
	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Date getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(Date createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	public Buyer(int id, String username, String password, String email, long mobileNumber, Date createdDateTime) {
		super();
		Id = id;
		this.username = username;
		Password = password;
		Email = email;
		this.mobileNumber = mobileNumber;
		this.createdDateTime = createdDateTime;
	}

	public Buyer() {
		super();
	}
	

}
