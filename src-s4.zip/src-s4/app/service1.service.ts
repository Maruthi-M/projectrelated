import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http';
import{Observable} from 'rxjs';
import{seller} from './seller';
import { modelproduct } from './modelproduct';

@Injectable({
  providedIn: 'root'
})
export class Service1Service {
  private baseUrl='http://localhost:8081/';
  private baseUrl1='http://localhost:8080';

  constructor(private http:HttpClient) { }
 getProductByName(productname: String):Observable<any> {
    return this.http.get(`${this.baseUrl}/getproductbyname/${productname}`);
  }
  addSeller(s:seller):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/addSeller/`,s);
  }
  addProduct(product:modelproduct):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/addProduct/2`,product);
  }
viewproducts():Observable<any>
{
  return this.http.get('http://localhost:8081/viewproducts/2');
}
/**deleteproduct/{sellerId}/{productId} */
deleteproduct(productId:number):Observable<any>
{
return this.http.delete(`${this.baseUrl}/deleteproduct/2/${productId}`);
}
}




