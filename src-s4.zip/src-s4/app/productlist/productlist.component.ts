import { Component, OnInit } from '@angular/core';
import { modelproduct } from '../modelproduct';
import { Service1Service } from '../service1.service';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {
productlist:modelproduct=new modelproduct();
p:any;
sid:number=2;
  constructor(private pservice:Service1Service) { }

  ngOnInit(): void {
    console.log("seller product list");
    this.pservice.viewproducts().subscribe(productlist=>this.productlist=productlist);
  }
onSubmit(pid)
{
  console.log("delete product by seller id method");
  this.pservice.deleteproduct(pid).subscribe(productlist=>this.productlist=productlist);
}
}
/** ngOnInit(): void {
    console.log("display cart component");
    this.productservice.getCartItemsById().subscribe(cartitems=>this.cartitems=cartitems);
  } */