import { Component, OnInit, Input, Output } from '@angular/core';
import { Modelproduct } from '../modelproduct';
import { Shoppingcart } from '../Shoppingcart';
import { Service1Service } from '../service1.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private productservice:Service1Service) { }
 @Input()
  product:Modelproduct;
cart:Shoppingcart=new Shoppingcart();
  ngOnInit(): void {
  
  }
  addToCart()
  {
this.cart.productId=this.product.productId;
this.cart.productName=this.product.productName;
this.cart.numberOfItems=1;
this.cart.price=this.product.price;
this.productservice.addCartItem(this.cart).subscribe(cart=>this.cart=cart);
  }

}
/*import { Component, OnInit,Input } from '@angular/core';
import {Product} from '../Product';
import {SellerserviceService} from '../sellerservice.service';
import { ShoppingCart } from '../ShoppingCart';

@Component({
  selector: 'app-productdetails',
  templateUrl: './productdetails.component.html',
  styleUrls: ['./productdetails.component.css']
})
export class ProductdetailsComponent implements OnInit {

  constructor(private productService:SellerserviceService) {}
@Input() 
product:Product;
cart:ShoppingCart=new ShoppingCart();

  ngOnInit(): void {
  }
  addToCart()
{
 
  this.cart.item=this.product.productId;
  this.cart.price=this.product.price;
  this.cart.numberofitems=1;
  console.log("productId......"+this.product.productId)
 // console.log("productId......"+this.product.price);
 this.productService.addCartItem(this.cart).subscribe(cart=>this.cart=cart);
}*/ 