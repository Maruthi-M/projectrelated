
package com.cts.SpringBoot.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.SpringBoot.Buyer;
import com.cts.SpringBoot.service.Projectservice;



@RestController
public class BuyerController {
	@Autowired 
	private Projectservice service;
	//sample for getting buyers from database
	@RequestMapping("getAllBuyers")
	public List<Buyer> getAllBuyers()
	{
		return service.getAllBuyers();
	}
	//adding buyer
	@RequestMapping(value="addBuyer" ,method=RequestMethod.POST,produces="application/json")
	public Buyer addBuyer(@RequestBody Buyer buyer)
	{
		return service.addbuyer(buyer);
		
	}
	
	/*@RequestMapping("getbyname/{name}")
	public Buyer getbyName(@PathVariable("bname") String name) {
	return service.getBuyerByName(name);
}*/
}
