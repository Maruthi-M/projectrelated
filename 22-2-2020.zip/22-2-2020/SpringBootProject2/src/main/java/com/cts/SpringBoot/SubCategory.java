package com.cts.SpringBoot;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="sub_category")
public class SubCategory implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int subcategoryId;
	private String subcategoryName;
	private String subcategoryDeatils;
	private float gst;
	public int getSubcategoryId() {
		return subcategoryId;
	}
	public void setSubcategoryId(int subcategoryId) {
		this.subcategoryId = subcategoryId;
	}
	public String getSubcategoryName() {
		return subcategoryName;
	}
	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}
	public String getSubcategoryDeatils() {
		return subcategoryDeatils;
	}
	public void setSubcategoryDeatils(String subcategoryDeatils) {
		this.subcategoryDeatils = subcategoryDeatils;
	}
	public float getGst() {
		return gst;
	}
	public void setGst(float gst) {
		this.gst = gst;
	}
	public SubCategory(int subcategoryId, Category category, String subcategoryName, String subcategoryDeatils,
			float gst) {
		super();
		this.subcategoryId = subcategoryId;
		this.subcategoryName = subcategoryName;
		this.subcategoryDeatils = subcategoryDeatils;
		this.gst = gst;
	}
	public SubCategory() {
		super();
	}
	

}
